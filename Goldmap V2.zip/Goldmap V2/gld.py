import pandas as pd

# Load the CSV file into a DataFrame
df = pd.read_csv(r"C:\Users\hambu\Desktop\gold\Goldmap V2\shallow.csv")

# Define the column range using column names
filter_c = df.loc[:, 'A_Depth':'A_Zn'].columns

# Convert non-numeric values to NaN and then to 0 for the specified columns
df[filter_c] = df[filter_c].apply(pd.to_numeric, errors='coerce').fillna(0)

# Display the updated DataFrame
print(df)

df.to_csv(r'C:\Users\hambu\Desktop\gold\Goldmap V2\newshallow.csv', index=False)