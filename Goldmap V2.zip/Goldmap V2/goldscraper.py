import pandas as pd

# Load the CSV file
file_path = '/mnt/data/Ahorizon.xlsx - A_Horizon.csv'
df = pd.read_csv(file_path)

# Define the thresholds for pathfinder elements and indicator minerals
thresholds_elements = {
    'A_Ag': 0.5,   # Example threshold for silver (mg/kg)
    'A_As': 10,    # Example threshold for arsenic (mg/kg)
    'A_Cu': 50,    # Example threshold for copper (mg/kg)
    'A_Pb': 20,    # Example threshold for lead (mg/kg)
    'A_Zn': 30,    # Example threshold for zinc (mg/kg)
    'A_Sb': 1,     # Example threshold for antimony (mg/kg)
    'A_Bi': 0.5,   # Example threshold for bismuth (mg/kg)
    'A_Hg': 0.1,   # Example threshold for mercury (mg/kg)
    'A_W': 0.5,    # Example threshold for tungsten (mg/kg)
    'A_Te': 0.1,   # Example threshold for tellurium (mg/kg)
    'A_Mo': 2,     # Example threshold for molybdenum (mg/kg)
    'A_Se': 0.5,   # Example threshold for selenium (mg/kg)
    'A_Ni': 20,    # Example threshold for nickel (mg/kg)
    'A_Fe': 5000,  # Example threshold for iron (mg/kg)
    'A_Co': 10,    # Example threshold for cobalt (mg/kg)
    'A_Th': 1,     # Example threshold for thorium (mg/kg)
    'A_La': 1      # Example threshold for lanthanum (mg/kg)
}

thresholds_minerals = {
    'A_Quartz': 70,      # Example threshold for quartz (wt. %)
    'A_Calcite': 5,      # Example threshold for calcite (wt. %)
    'A_Hematite': 1,     # Example threshold for hematite (wt. %)
    'A_Goethite': 1,     # Example threshold for goethite (wt. %)
    'A_Pyrite': 0.1,     # Example threshold for pyrite (wt. %)
    'A_Dolomite': 1,     # Example threshold for dolomite (wt. %)
    'A_Gypsum': 0.5,     # Example threshold for gypsum (wt. %)
    'A_Talc': 0.5,       # Example threshold for talc (wt. %)
    'A_Serpent': 0.5     # Example threshold for serpentinite (wt. %)
}

# Function to check if a row meets any of the thresholds
def row_meets_threshold(row, thresholds):
    for element, threshold in thresholds.items():
        try:
            if float(row[element]) > threshold:
                return True
        except ValueError:
            continue
    return False

# Remove rows from Alaska
df_filtered = df[df['StateID'] != 'AK']

# Remove the specified columns
columns_to_remove = ['LandCover1', 'LandCover2', 'CollDate']
df_filtered = df_filtered.drop(columns=columns_to_remove)

# Filter rows that meet the thresholds for elements or minerals
filtered_df = df_filtered[df_filtered.apply(lambda row: row_meets_threshold(row, thresholds_elements) or row_meets_threshold(row, thresholds_minerals), axis=1)]

# Save the filtered DataFrame to a new CSV file
output_file_path = '/mnt/data/Filtered_Gold_Indication_Data.csv'
filtered_df.to_csv(output_file_path, index=False)


